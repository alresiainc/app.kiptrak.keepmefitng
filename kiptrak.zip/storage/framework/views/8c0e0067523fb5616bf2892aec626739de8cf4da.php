
<?php $__env->startSection('title'); ?>Add Role <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Add Role</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Add Role</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

      </div>
    </section>

    <?php if(Session::has('success')): ?>
    <div class="alert alert-success mb-3 text-center">
        <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>

    <?php if(Session::has('role_error')): ?>
    <div class="alert alert-danger mb-3 text-center">
        <?php echo e(Session::get('role_error')); ?>

    </div>
    <?php endif; ?>

    <section>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              
              <form class="row g-3 needs-validation" action="<?php echo e(route('addRolePost')); ?>" method="POST"><?php echo csrf_field(); ?>
                <div class="col-md-12">
                  <label for="" class="form-label">Role Name</label>
                  <input type="text" name="role_name" class="form-control <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="">
                  <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-12">
                    <div class="row mt-5">
                        <div class="d-flex justify-content-between">
                            <div class="heading">
                                <figure class="text-left">
                                    <blockquote class="blockquote">
                                      <p class="fw-bold">Permissions</p>
                                    </blockquote>
                                    <figcaption class="blockquote-footer">
                                        Tick Appropriate Permissions
                                    </figcaption>
                                </figure>                            
                            </div>

                            <button type="button" class="btn btn-sm text-white d-none"
                                style="background-color: #093040; height: 30px;"
                                data-bs-target="#importModal" data-bs-toggle="modal" data-bs-placement="auto" data-bs-title="Export Data">
                                <i class="fa fa-plus"></i>
                                Add Permissions</button>
                        </div>

                        <!--permissions-->
                        <div>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="main-card mb-3 card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($perm->name); ?> PERMISSIONS</h5>
                                    <?php if(!empty($perm->permissions)): ?>
                                        <?php $__currentLoopData = $perm->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="position-relative form-check form-check-inline">
                                            <label class="form-check-label">
                                                <input type="checkbox" class="form-check-input" name="perms[]" value="<?php echo e($sub_perm->id); ?>">
                                                <?php echo e($sub_perm->name); ?>

                                            </label>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>

                        

                    </div>
                </div>
                
                <div class="text-end">
                  <button type="submit" class="btn btn-primary">Save Role</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- End Multi Columns Form -->
              
            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\git-version\crm-app\crm-app\resources\views/pages/hrm/role/addRole.blade.php ENDPATH**/ ?>
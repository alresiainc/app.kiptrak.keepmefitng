<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0, user-scalable=0"
            name="viewport">

        <title>Order Form :: CRM</title>
        <meta content="" name="description">
        <meta content="" name="keywords">

        <!-- Favicons -->
        <link href="<?php echo e(asset('/customerform/assets/img/favicon.png')); ?>" rel="icon">
        <link href="<?php echo e(asset('/customerform/assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
        <!-- Google Fonts -->
        <link href="https://fonts.gstatic.com" rel="preconnect">
        <link
            href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
            rel="stylesheet">

        <!-- Vendor CSS Files -->
        <link href="<?php echo e(asset('/customerform/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/customerform/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
        <!-- Latest compiled and minified CSS -->
        
    
        <!-- Font awesome 5 -->
        <link rel="preload" href="<?php echo e(asset('/customerform/assets/vendor/font-awesome/webfonts/fa-solid-900.woff2')); ?>" as="font" type="font/woff" crossorigin>
        <link href="<?php echo e(asset('/customerform/assets/vendor/font-awesome/css/all.min.css')); ?>" type="text/css" rel="stylesheet">

        
        <!-- Template Main CSS File -->
        <link href="<?php echo e(asset('/customerform/assets/css/ui.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/customerform/assets/css/form-style.css')); ?>" rel="stylesheet">


    </head>

    <body class="">

        <!-- will be shown in singlelink-->
        <!--nav-bar-->

    <div class="container">
        
        
        
        <!-- CHECKOUT VIEW -->
        <div class="row view" id="checkout">
            
                
            <div class="col-md-12">

                <article class="card">
                    <div class="card-body">
                        <h5 class="card-title">Contact info</h5>
                        <form action="<?php echo e(route('formLinkPost', $unique_key)); ?>" method="POST"><?php echo csrf_field(); ?>
                            <div class="row">

                                <?php $__currentLoopData = $formContact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 mb-3">
                                    <label class="form-label"><?php echo e($contact['label']); ?></label>
                                    <input type="<?php echo e($contact['type']); ?>" name="<?php echo e($contact['name']); ?>" class="form-control <?php $__errorArgs = [<?php echo e($contact['name']); ?>];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Type here">
                                    <?php $__errorArgs = [<?php echo e($contact['name']); ?>];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- col end.// -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <hr>
                                <div class="col-12 mb-1 mt-3 fw-bolder">Select A Package From Below</div>
                                
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 mb-3">
                                    <label for="package<?php echo e($key); ?>" class="form-label btn btn-outline border d-flex align-items-center me-3">
                                        <input type="<?php echo e($item['type']); ?>" name="package[]" id="package<?php echo e($key); ?>" class="contact-check me-3" value="<?php echo e($item['value']); ?>"/>
                                        <span class="me-1 fw-bold"><?php echo e($item['label']); ?> = <?php echo e($item['product_price']); ?> naira</span>
                                    </label>
                                </div> <!-- col end.// -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-12">
                                    <div class="d-flex justify-content-center">
                                        <button type="submit" class="btn btn-success w-50">Submit Order</button>
                                    </div>
                                </div>
                                    
                            </div> <!-- row.// --> 
                            
                        </form>
                        
                        
                    </div> <!-- card-body end.// -->
                </article>

            </div>
            
        </div>
    </div>

    <!-- <hr> will be shown in singlelink-->
    <!--footer--->

        <!-- Vendor JS Files -->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        
        <script src="<?php echo e(asset('/customerform/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        


    </body>

</html><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/formEmbedded.blade.php ENDPATH**/ ?>
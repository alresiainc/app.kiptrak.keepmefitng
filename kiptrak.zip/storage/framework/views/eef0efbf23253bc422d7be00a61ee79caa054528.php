
<?php $__env->startSection('title'); ?>View Product <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Product Information</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Product Information<li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <hr>
    <section>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            
            <div class="card-body pt-3">
              <div class="card-title clearfix">
                <div class="d-lg-flex d-grid align-items-center float-start">
                  <div>
                    <a
                    href="<?php echo e(asset('/storage/products/'.$product->image)); ?>"
                    data-caption="<?php echo e(isset($product->name) ? $product->name : 'no caption'); ?>"
                    data-fancybox
                    > 
                    <img src="<?php echo e(asset('/storage/products/'.$product->image)); ?>" width="100" class="img-thumbnail img-fluid"
                    alt="Photo"></a>
                  </div>
                  <div class="d-grid ms-lg-3">
                    <div class="display-6"><?php echo e($product->name); ?></div>
                    <h5><?php echo e($currency_symbol); ?><?php echo e($product->price); ?></h5>

                    <?php if($stock_available > 0): ?>
                      <div class="d-flex justify-content-start">
                        <small class="text-success me-2">(In-Stock)</small><small>Lagos Warehouse</small>
                      </div>
                    <?php else: ?>
                      <small class="text-danger">(Out-Of-Stock) | Lagos Warehouse</small>
                    <?php endif; ?>
                    
                  </div>
                </div>
                <div class="float-lg-end">
                  <button class="btn btn-sm btn-success"><i class="bi bi-pencil-square"></i></button>
                </div>
              </div>

              <hr>

              <div class="row g-3">
                <div class="col-lg-3">
                  <label for="">SKU Code</label>
                  <div class="lead"><?php echo e($product->code); ?></div>
                </div>

                <?php if(isset($product->color)): ?>
                <div class="col-lg-3">
                  <label for="">Color</label>
                  <div class="lead"><?php echo e($product->color); ?></div>
                </div>
                <?php endif; ?>
                
                <?php if(isset($product->size)): ?>
                <div class="col-lg-3">
                  <label for="">Size</label>
                  <div class="lead"><?php echo e($product->size); ?></div>
                </div>
                <?php endif; ?>
                
                <div class="col-lg-3">
                  <label for="">Quantity</label>
                  <div class="lead"><?php echo e($stock_available); ?></div>
                </div>
                
              </div>

              <!--features-->
              <?php if($features != ''): ?>
                  
                <hr>
                <div class="row g-1">

                  <div class="col-lg-12">
                    <label for="">Features</label>
                  </div>

                  <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                      <?php echo e($feature); ?>

                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>

              <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/products/singleProduct.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>View Product <?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_css'); ?>
    <style>
        .camera{
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
<script>
   const download = () => {
      html2canvas(document.querySelector('#upsell-section')).then(canvas => {
         document.getElementById('output').appendChild(canvas);
      });
   }
</script>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Upsell Template</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active">Upsell Template<li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    
    <hr>
    <section>
        <div class="row view" id="upsell-section">
                
            <div class="col-md-12">

                <!--design-starts-->
                <article class="card <?php if($upsellTemplate->body_border_radius != 'normal'): ?> <?php echo e($upsellTemplate->body_border_radius); ?> <?php endif; ?>"
                style="background-color: <?php echo e($upsellTemplate->body_bg_color); ?>;
                border-style: <?php echo e($upsellTemplate->body_border_style); ?>;
                border-color: <?php echo e($upsellTemplate->body_border_color); ?>;
                border-width: <?php echo e($upsellTemplate->body_border_thickness); ?>;
                "
                >
                    <div class="card-body">
                        
                        
                        <div class="row">

                            <!--upsell-->
                            <div class="col-12 mb-3">
                                <div class="d-flex justify-content-center">
                                    <div class="content p-3">
                                        <h3 class="heading text-<?php echo e($upsellTemplate->heading_text_align); ?> fst-<?php echo e($upsellTemplate->heading_text_style); ?>"
                                        style="color: <?php echo e($upsellTemplate->heading_text_color); ?>;"><?php echo e($upsellTemplate->heading_text); ?></h3>

                                        <h4 class="subheading text-<?php echo e($upsellTemplate->subheading_text_align); ?> fst-<?php echo e($upsellTemplate->subheading_text_style); ?>"
                                        style="color: <?php echo e($upsellTemplate->subheading_text_color); ?>;"><?php echo e($upsellTemplate->subheading_text); ?></h4>
                                        
                                        <?php if(isset($upsellTemplate->description_text)): ?>
                                        <p class="description text-<?php echo e($upsellTemplate->description_text_align); ?> fst-<?php echo e($upsellTemplate->description_text_style); ?>"
                                        style="color: <?php echo e($upsellTemplate->description_text_color); ?>;">
                                            <?php echo e($upsellTemplate->description_text); ?>

                                        </p>
                                        <?php endif; ?>
                                        
                                        <div class="upsell-product-image mb-3">
                                            <img src="https://via.placeholder.com/400.png?text=Product+Image" class="img-thumbnail img-fluid"
                                            alt="">
                                        </div>

                                        <div class="select-upsell-product text-center">
                                            <p class="form-label">Click button to Add Product Package</p>
                                            <div class="call-to-action d-flex justify-content-center align-items-center">
                                                <label for="upsell_product" class="form-label d-flex align-items-center">
                                                    
                                                    <span class="text-<?php echo e($upsellTemplate->package_text_align); ?> fst-<?php echo e($upsellTemplate->package_text_style); ?>"
                                                    style="color: <?php echo e($upsellTemplate->package_text_color); ?>;">Sample Package Title =
                                                        N(Sample Package Title Price)</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="make-your-choice">

                                            <button type="submit" class="btn w-100 p-2 upsell_submit_btn text-<?php echo e($upsellTemplate->button_text_align); ?> fst-<?php echo e($upsellTemplate->button_text_style); ?>"
                                                style="background-color: #012970; color: <?php echo e($upsellTemplate->button_text_color); ?>;">ADD TO MY ORDER</button>

                                        </div>
                                        
                                            
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-12">
                                <div class="make-your-choice d-flex justify-content-center">

                                    <label for="upsell_refusal" class="form-label d-flex align-items-center">
                                        <input type="checkbox" name="upsell_refusal" id="upsell_refusal" class="cta-check2 me-1 upsell_refusal invisible"
                                        <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checked <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="true"/>
                                        <span class="fw-light" style="color: #012970;">No, thank you</span>
                                    </label>

                                </div>
                            </div>
                                
                        </div> <!-- row.// --> 
                            
                    </div> <!-- card-body end.// -->
                </article>
                <!--design-ends-->

            </div>

        </div>
    </section>

    <div id="camera" class="col-md-12 text-center d-none">
        <div onclick="download()"><i class="bi bi-camera-fill text-dark p-1 display-1 camera"></i></div>
    </div>

    <section id="output"></section>

</main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_ja'); ?>


<script>
  
    // Define the function 
    // to screenshot the div
    function takeshot() {
        alert('122')
        let div =
            document.getElementById('camera');

        // Use the html2canvas
        // function to take a screenshot
        // and append it
        // to the output div
        html2canvas(div).then(
            function (canvas) {
                document
                .getElementById('output')
                .appendChild(canvas);
            })
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\git-version\crm-app\crm-app\resources\views/pages/settings/upsell/singleUpsellTemplate.blade.php ENDPATH**/ ?>
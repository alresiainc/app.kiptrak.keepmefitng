
<?php $__env->startSection('title'); ?>Dashboard <?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_css'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<main id="main" class="main">
  <div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
    </nav>
  </div>
  <!-- End Page Title -->

  <!-- Alert -->
  <div id="liveAlertPlaceholder d-none"></div>
  <!-- /Alert -->

  <div class="text-lg-end text-center mb-3">
    <div class="btn-group" role="group" aria-label="Basic example">
      <button type="button" class="btn btn-sm btn-light-success active">
        Today
      </button>
      <button type="button" class="btn btn-sm btn-light-success">
        Weekly
      </button>
      <button type="button" class="btn btn-sm btn-light-success">
        Monthly
      </button>
      <button type="button" class="btn btn-sm btn-light-success">
        Yearly
      </button>
      <button type="button" class="btn btn-sm btn-light-success">
        All
      </button>
    </div>
  </div>
  <hr />

  <section class="section m-0">
    <div class="row">
      <!-- Sales Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card bg-1">
          <div class="card-body p-2">
            <div class="d-flex justify-content-between align-items-center">
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($generalSetting->country->symbol); ?><?php echo e(number_format((float)$purchases_amount_paid, 2, '.', ',')); ?></h2>
                <small class="text-uppercase small pt-1 fw-bold"
                  >Purchases</small
                >
              </div>
              <div class="rounded-circle float-end">
                <i class="bi bi-box display-1 text-light-black"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Sales Card -->

      <!-- Sales Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card bg-2">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-between">
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($generalSetting->country->symbol); ?><?php echo e(number_format((float)$sales_paid, 2, '.', '')); ?></h2>
                <small class="text-uppercase small pt-1 fw-bold">Sales</small
                >
              </div>
              <div class="rounded-circle float-end">
                <i
                  class="bi bi-calendar-minus display-1 text-light-black"
                ></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Sales Card -->

      <!-- Sales Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card bg-3">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-between">
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($generalSetting->country->symbol); ?><?php echo e(number_format((float)$expenses, 2, '.', ',')); ?></h2>
                <small class="text-uppercase small pt-1 fw-bold">Expenses</small
                >
              </div>
              <div class="rounded-circle float-end">
                <i class="bi bi-cart-check display-1 text-light-black"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Sales Card -->

      <!-- Sales Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card bg-4">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-between">
              <div class="text-start">
                <h2 class="fw-bold">
                  <?php if($profit > 0): ?>
                  <?php echo e($generalSetting->country->symbol); ?><?php echo e(number_format((float)$profit, 2, '.', ',')); ?>

                  <?php else: ?>
                  (<?php echo e(number_format((float)abs($profit), 2, '.', ',')); ?>)
                  <?php endif; ?>
                  
                </h2>
                <small class="text-uppercase small pt-1 fw-bold">Profit</small
                >
              </div>
              <div class="rounded-circle float-end">
                <i class="bi bi-cash-coin display-1 text-light-black"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Sales Card -->
    </div>
  </section>

  <section class="section m-0">
    <div class="row">
      <!-- Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card border-right-warning card-right-border">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-start">
              <div class="border rounded shadow-sm px-2 me-2">
                <i class="bi bi-people display-1 text-light-black"></i>
              </div>
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($customers_count); ?></h2>
                <small class="text-uppercase text-muted small pt-1 fw-bold">Customers</small
                >
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Card -->
      <!-- Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card border-right-primary card-right-border">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-start">
              <div class="border rounded shadow-sm px-2 me-2">
                <i class="bi bi-truck display-1 text-light-black"></i>
              </div>
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($suppliers_count); ?></h2>
                <small class="text-uppercase text-muted small pt-1 fw-bold">Suppliers</small
                >
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Card -->

      <!-- Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card border-right-success card-right-border">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-start">
              <div class="border rounded shadow-sm px-2 me-2">
                <i class="bi bi-briefcase display-1 text-light-black"></i>
              </div>
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($purchases_count); ?></h2>
                <small class="text-uppercase text-muted small pt-1 fw-bold">Purchases</small
                >
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Card -->

      <!-- Card -->
      <div class="col-lg-3 col-md-6">
        <div class="card border-right-danger card-right-border">
          <div class="card-body p-2">
            <div class="d-flex align-items-center justify-content-start">
              <div class="border rounded shadow-sm px-2 me-2">
                <i
                  class="bi bi-receipt display-1 text-light-black"
                ></i>
              </div>
              <div class="text-start">
                <h2 class="fw-bold"><?php echo e($sales_count); ?></h2>
                <small class="text-uppercase text-muted small pt-1 fw-bold">Sales</small
                >
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Card -->
    </div>
  </section>

  <hr />

  <section class="section">
    <div class="row">
      <!-- Reports -->
      <div class="col-md-8">
        <div class="card card-top-border border-top-success">
          <div class="card-body">
            <h5 class="card-title">Purchase, Sales & Expense Chart</h5>

            <!-- Line Chart -->
            <!-- <div id="reportsChart"></div> -->
            <div>
              
              <canvas class="bar-chartcanvas" data-sale_chart_value = "<?php echo e(json_encode($yearly_sale_amount)); ?>" data-purchase_chart_value = "<?php echo e(json_encode($yearly_purchase_amount)); ?>"
              data-expense_chart_value = "<?php echo e(json_encode($yearly_expense_amount)); ?>" data-label1="Purchase" data-label2="Sales" data-label3="Expenses"></canvas>
              

            </div>

            <!-- End Line Chart -->
          </div>
        </div>
      </div>
      <!-- End Reports -->

      <div class="col-md-4">
        <div class="card border-top-5 border-top-warning card-top-border">
          <div class="card-body">
            <div class="card-title">Recently Added Items</div>

            <table class="table">
              <thead>
                <tr>
                  <th scope="col">Photo</th>
                  <th scope="col">Item</th>
                  <th scope="col">Purchase Price</th>
                </tr>
              </thead>
              <tbody>

                <?php if(count($recentProducts) > 0): ?>
                  <?php $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row">
                      <a
                        href="<?php echo e(asset('/storage/products/'.$product->image)); ?>"
                        data-fancybox="gallery"
                        data-caption="<?php echo e(isset($product->name) ? $product->name : 'no caption'); ?>"
                        >   
                        <img src="<?php echo e(asset('/storage/products/'.$product->image)); ?>" width="50" class="img-thumbnail img-fluid"
                        alt="<?php echo e($product->name); ?>" style="height: 30px;"></a>
                    </th>
                    <td class="align-middle fw-bold" style="font-size: 10px;"><?php echo e($product->name); ?></td>
                    <td class="align-middle"><?php echo e($generalSetting->country->symbol); ?><?php echo e($product->purchase_price); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="row">
      <div class="col-md-12">
        <div class="card card-top-border border-top-primary">
          <div class="card-body">
            <div class="card-title">Stock Alert</div>
            <div class="table table-responsive">
              <table
                id="stock-table"
                class="table table-striped"
                style="width: 100%"
              >
                <thead>
                  <tr>
                    <th scope="col">Item Code</th>
                    <th scope="col">Item Name</th>
                    
                    <th scope="col">Stock</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($products->count() > 0): ?>
                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($product->stock_available() < 10): ?>
                          <tr>
                            <td><?php echo e($product->code); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->stock_available()); ?></td>
                          </tr>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="row">
      <!-- Reports -->
      <div class="col-lg-6">
        <div class="card card-top-border border-top-success">
          <div class="card-body">
            <h5 class="card-title">Top 5 Selling Products</h5>

            <!-- Line Chart -->
            <div>
              <canvas id="trendingItemsChart" width="100%"></canvas>
            </div>

            <!-- End Line Chart -->
          </div>
        </div>
      </div>
      <!-- End Reports -->

      <div class="col-lg-6">
        <div class="card border-top-5 border-top-warning card-top-border">
          <div class="card-body">
            <div class="card-title">Recent Orders</div>

            <table class="table">
              <thead>
                <tr>
                  <th scope="col">Order No.</th>
                  <th scope="col">Customer</th>
                  <th scope="col">Delivery Address</th>
                  <th scope="col">Agent</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php if($recentOrders->count() > 0): ?>
                 <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                  <td><?php echo e($order->orderCode($order->id)); ?></td>
                  <td><?php echo e($order->customer_id ? $order->customer->firstname : 'No response'); ?> <?php echo e($order->customer_id ? $order->customer->lastname : ''); ?></td>
                  <td style="width: 150px;"><?php echo e($order->customer_id ? $order->customer->delivery_address : 'No response'); ?></td>

                  <?php if(isset($order->agent_assigned_id)): ?>
                  <td>
                    <?php echo e($order->agent->name); ?>

                  </td>
                  <?php else: ?>
                  <td style="width: 120px">
                    None 
                  </td>
                  <?php endif; ?>

                  <td>
                    
                      <?php if(!isset($order->status) || $order->status=='pending'): ?>
                        <span class="badge badge-danger">Pending</span>
                      <?php endif; ?>
                      
                  </td>
                </tr> 
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php endif; ?>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>


<script>
  $(document).ready(function () {
    $("#stock-table").DataTable({
      dom: "Bflrtip",
      buttons: {
        buttons: [
          { extend: "copy", className: "btn btn-teal btn-sm" },
          { extend: "excel", className: "btn btn-teal btn-sm" },
          { extend: "pdf", className: "btn btn-teal btn-sm" },
          { extend: "print", className: "btn btn-teal btn-sm" },
          { extend: "csv", className: "btn btn-teal btn-sm" },
        ],
      },
    });

    const alertPlaceholder = document.getElementById(
      "liveAlertPlaceholder"
    );

    const alert = (message, type) => {
      const wrapper = document.createElement("div");
      wrapper.innerHTML = [
        `<div class="alert alert-${type} alert-dismissible" role="alert">`,
        `   <div>${message}</div>`,
        '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
        "</div>",
      ].join("");

      alertPlaceholder.append(wrapper);
    };

    alert("Nice, you triggered this alert message!", "danger");
  });
</script>

<?php if($yearly_best_selling_qty->count() == 5): ?>
<script>
  //trendingItemsChart
  var trendingItemsChart = document.getElementById("trendingItemsChart");
  var _trendingItemsChart = new Chart(trendingItemsChart, {
    type: 'doughnut',
    data: {
      labels: [
        "<?php echo e($bestSellingProductsBulk[0]['product_name']); ?>",
        "<?php echo e($bestSellingProductsBulk[1]['product_name']); ?>",
        "<?php echo e($bestSellingProductsBulk[2]['product_name']); ?>",
        "<?php echo e($bestSellingProductsBulk[3]['product_name']); ?>",
        "<?php echo e($bestSellingProductsBulk[4]['product_name']); ?>",
        // "Colgate toothpaste",
        // "Redmi Note 10-64GB",
      ],
      datasets: [{
          label: 'Top Items',
          // data: ["<?php echo e($yearly_best_selling_qty[0]->sold_qty); ?>", "<?php echo e($yearly_best_selling_qty[1]->sold_qty); ?>", "<?php echo e($yearly_best_selling_qty[2]->sold_qty); ?>",
          // "<?php echo e($yearly_best_selling_qty[2]->sold_qty); ?>", "<?php echo e($yearly_best_selling_qty[2]->sold_qty); ?>"],
          data: [<?php echo e($bestSellingProductsBulk[0]['sold_qty']); ?>, <?php echo e($bestSellingProductsBulk[1]['sold_qty']); ?>, <?php echo e($bestSellingProductsBulk[2]['sold_qty']); ?>,
          <?php echo e($bestSellingProductsBulk[3]['sold_qty']); ?>, <?php echo e($bestSellingProductsBulk[4]['sold_qty']); ?>],
          backgroundColor: [
          'rgb(102, 102, 255)',
          'rgb(255, 51, 153)',
          'rgb(0, 204, 153)',
          'rgb(204, 204, 0)',
          'rgb(37, 195, 72)',
          // 'rgb(31, 161, 212, 1)',
          // 'rgb(238, 27, 37, 1)'
          ],
          hoverOffset: 4
      }]
    },
    //options
  });
</script>
<?php endif; ?>



<script>
   'use strict';

  window.chartColors = {
    red: "rgb(255, 50, 10)",
    orange: "rgb(255, 102, 64)",
    yellow: "rgb(230, 184, 0)",
    green: "rgb(0, 179, 0)",
    blue: "rgb(0, 0, 230)",
    purple: "rgb(134, 0, 179)",
    grey: "rgb(117, 117, 163)",
  };

  var MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  var COLORS = [
    "#4dc9f6",
    "#f67019",
    "#f53794",
    "#537bc4",
    "#acc236",
    "#166a8f",
    "#00a950",
    "#58595b",
    "#8549ba",
  ];

  //BAR CHART, YEARLY REPORT, PURCHASE, SALES, EXPENSES
  $(function () {
    //get the bar chart canvas
    var ctx = $(".bar-chartcanvas");

    var yearly_sale_amount = ctx.data('sale_chart_value');
    var yearly_purchase_amount = ctx.data('purchase_chart_value');
    var yearly_expense_amount = ctx.data('expense_chart_value');
    var label1 = ctx.data('label1');
    var label2 = ctx.data('label2');

    //bar chart data
    var data = {
      labels: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ],
      datasets: [
        {
          label: "Purchase",
          data: [ yearly_purchase_amount[0], yearly_purchase_amount[1], yearly_purchase_amount[2], yearly_purchase_amount[3], yearly_purchase_amount[4], yearly_purchase_amount[5],
                  yearly_purchase_amount[6], yearly_purchase_amount[7], yearly_purchase_amount[8], yearly_purchase_amount[9], yearly_purchase_amount[10], yearly_purchase_amount[11],
                  0],
          borderColor: window.chartColors.red,
          backgroundColor: window.chartColors.red,
          borderWidth: 1,
        },
        {
          label: "Sales",
          data: [ yearly_sale_amount[0], yearly_sale_amount[1], yearly_sale_amount[2], yearly_sale_amount[3], yearly_sale_amount[4], yearly_sale_amount[5],
                  yearly_sale_amount[6], yearly_sale_amount[7], yearly_sale_amount[8], yearly_sale_amount[9], yearly_sale_amount[10], yearly_sale_amount[11],
                  0],
          borderColor: window.chartColors.blue,
          backgroundColor: window.chartColors.blue,
          borderWidth: 1,
        },
        {
          label: "Expense",
          data: [ yearly_expense_amount[0], yearly_expense_amount[1], yearly_expense_amount[2], yearly_expense_amount[3], yearly_expense_amount[4], yearly_expense_amount[5],
                  yearly_expense_amount[6], yearly_expense_amount[7], yearly_expense_amount[8], yearly_expense_amount[9], yearly_expense_amount[10], yearly_expense_amount[11],
                  0],
          borderColor: window.chartColors.green,
          backgroundColor: window.chartColors.green,
          borderWidth: 1,
        },
      ],
    };

    //options
    var options = {
      responsive: true,
      title: {
        display: true,
        position: "top",
        fontSize: 18,
        fontColor: "#111",
      },
      legend: {
        display: true,
        position: "top",
        labels: {
          fontColor: "#333",
          fontSize: 16,
        },
      },
      scales: {
        yAxes: [
          {
            ticks: {
              min: 0,
            },
          },
        ],
      },
    };
    //create Chart class object
    var chart = new Chart(ctx, {
      type: "bar",
      data: data,
      options: options,
    });
    //end-bar-chartcanvas
  


  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\git-version\crm-app\crm-app\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>
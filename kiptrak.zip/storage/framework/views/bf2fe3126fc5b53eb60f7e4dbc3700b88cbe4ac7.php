<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp\htdocs\crm\git-version\crm-app\crm-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>
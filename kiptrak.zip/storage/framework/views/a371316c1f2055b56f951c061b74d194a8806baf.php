
<?php $__env->startSection('title'); ?>View Warehouse <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Warehouse Information</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Warehouse Information<li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <hr>
    <section>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            
            <div class="card-body pt-3">
              <div class="card-title clearfix">
                <div class="d-lg-flex d-grid align-items-center float-start">
                  
                  <div class="d-grid ms-lg-3">
                    <div class="display-6"><?php echo e($warehouse->name); ?></div>
                    <h5><?php echo e($warehouse->state); ?> | <?php echo e($warehouse->country->name); ?></h5>

                    <?php if($warehouse->status == 'true'): ?>
                      <div class="d-flex justify-content-start">
                        <small class="text-success me-2">Active</small>
                      </div>
                    <?php else: ?>
                      <small class="text-danger">Inactive</small>
                    <?php endif; ?>
                    
                  </div>
                </div>
                <div class="float-lg-end">
                  <button class="btn btn-sm btn-success"><i class="bi bi-pencil-square"></i></button>
                </div>
              </div>

              <hr>

              <div class="row g-3">
                <div class="col-lg-3">
                  <label for="">Code</label>
                  <div class="lead">0<?php echo e($warehouse->id); ?></div>
                </div>

                <?php if(isset($warehouse->agent_id)): ?>
                <div class="col-lg-3">
                  <label for="">Agent</label>
                  <div class="lead"><?php echo e($warehouse->agent->name); ?></div>
                </div>
                <?php endif; ?>

                <?php if(isset($warehouse->city)): ?>
                <div class="col-lg-3">
                  <label for="">City / Town</label>
                  <div class="lead"><?php echo e($warehouse->city); ?></div>
                </div>
                <?php endif; ?>
                
                <?php if(isset($warehouse->state)): ?>
                <div class="col-lg-3">
                  <label for="">State</label>
                  <div class="lead"><?php echo e($warehouse->state); ?> | <?php echo e($warehouse->country->name); ?></div>
                </div>
                <?php endif; ?>
                
                
                
              </div>

              
            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/warehouses/singleWarehouse.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>View Order <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Order Information</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Order Information<li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <hr>
    <section>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            
            <div class="row g-3 m-1">
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Order Code</label>
                    <div class="text-dark display-6"><?php echo e($order->orderCode($order->id)); ?></div>
                </div>
                <div class="col-lg-5">
                    <label for="" class="fw-bolder">Customer</label>
                    <div class="text-dark"><?php echo e($order->customer_id ? $order->customer->firstname : 'N/A'); ?> <?php echo e($order->customer_id ? $order->customer->lastname : 'N/A'); ?>

                        | Email: <span class="lead"><?php echo e($order->customer_id ? $order->customer->email : 'N/A'); ?></div>
                    <div>Phone:  <span class="lead"><?php echo e($order->customer_id ? $order->customer->phone_number : 'N/A'); ?></span><br>
                        <?php if($order->customer_id): ?>
                    
                        <?php
                            $whatsapp = substr($order->customer->whatsapp_phone_number, 1)
                        ?>
                        Whatsapp:  <span class="lead"><a href="https://wa.me/<?php echo e('234'.$whatsapp); ?>?text=Hi" target="_blank">
                            <?php echo e($order->customer->whatsapp_phone_number); ?></a></span>
                        <?php else: ?>
                            Whatsapp:  <span class="lead">None</span>
                        <?php endif; ?>
                        
                    </div>
                    <div>Location:  <span class="lead"><?php echo e($order->customer_id ? $order->customer->city : 'None'); ?>, <?php echo e($order->customer_id ? $order->customer->state : 'None'); ?></span></div>
                    <div>Delivery Address:  <span class="lead"><?php echo e($order->customer_id ? $order->customer->delivery_address : 'None'); ?></span></div>
                    
                </div>
                <div class="col-lg-2">
                    <label for="" class="fw-bolder">Expected Revenue</label>
                    <div class="text-dark display-6"><?php echo e($currency); ?><?php echo e($gross_revenue); ?></div>
                </div>
                <div class="col-lg-2">
                    <label for="" class="fw-bolder">Agent</label>
                    <div class="text-dark"><?php echo e($order->agent_assigned_id ? $order->agent->name : 'None'); ?></div>
                </div>
            </div>

            <div class="row g-3 m-1">
                <div class="col-lg-3">

                </div>
            </div>

            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <hr>
            <div class="row g-3 m-1">
            
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Product Name</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($package['product']->name); ?></div>
                </div>

                
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Quantity Ordered</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($package['quantity_removed'].' @'. $package['product']->price); ?></div>
                </div>
                
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Revenue</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($package['revenue']); ?></div>
                </div>
                
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Date</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($order->created_at); ?></div>
                </div>
            
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

              <!--features-->
              

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/orders/singleOrder.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>Forms <?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_css'); ?>
    <style>
      td{
        font-size: 14px;
      }
      .btn-light {
          background-color: #fff !important;
          color: #000 !important;
      }
      div.filter-option-inner-inner{
          color: #000 !important;
      }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
    <h1>Forms</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active">Forms</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  
  <section class="users-list-wrapper">
    <div class="users-list-filter px-1">
      <form>
        <div class="row border rounded py-2 mb-2">

          <div class="col-12 col-md-6 col-lg-3 d-flex align-items-end">
            <div class="d-grid w-100">
              <a href="<?php echo e(route('newFormBuilder')); ?>" class="btn btn-primary btn-block glow users-list-clear mb-0">
                <i class="bx bx-plus"></i>Build Form</a>
            </div>
          </div>

        </div>
      </form>
    </div>

  </section>
  <?php if(Session::has('success')): ?>
  <div class="alert alert-success mb-3 text-center">
      <?php echo e(Session::get('success')); ?>

  </div>
  <?php endif; ?>
  <section>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body pt-3">
            
          <div class="clearfix mb-2">
            <div class="float-end text-end">
              <button data-bs-target="#importModal" class="btn btn-sm btn-dark rounded-pill" data-bs-toggle="modal" data-bs-toggle="tooltip" data-bs-placement="auto" data-bs-title="Export Data">
                <i class="bi bi-upload"></i> <span>Import</span></button>
              <button class="btn btn-sm btn-secondary rounded-pill" data-bs-toggle="tooltip" data-bs-placement="auto" data-bs-title="Import Data"><i class="bi bi-download"></i> <span>Export</span></button>
              <button class="btn btn-sm btn-danger rounded-pill" data-bs-toggle="tooltip" data-bs-placement="auto" data-bs-title="Delete All"><i class="bi bi-trash"></i> <span>Delete All</span></button>
            </div>
          </div>
          <hr>
          
          <div class="table table-responsive">
            <table id="orders-table" class="table table-striped custom-table" style="width:100%">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Form Code</th>
                  
                  
                  <th scope="col">OrderId</th>
                  <th scope="col">OrderBump</th>
                  <th scope="col">UpSell</th>
                  <th scope="col">Customer</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>

                <?php if(count($formHolders) > 0): ?>
                  <?php $__currentLoopData = $formHolders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$formHolder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e(++$key); ?></th>
                      <td><?php echo e($formHolder->slug); ?> <br>
                        <a class="btn btn-info btn-sm rounded" href="<?php echo e(route('editNewFormBuilder', $formHolder->unique_key)); ?>">
                          <i class="bi bi-pencil"></i> Edit</a>
                      </td>
                      
                      
                      
                      <td>
                        <a href="<?php echo e(route('singleOrder', $formHolder->order->unique_key)); ?>" class="btn btn-light border border-success rounded-pill p-1">
                          <!-- < 10 -->
                          <?php if($formHolder->order->id < 10): ?> 0000<?php echo e($formHolder->order->id); ?> <?php endif; ?>
                          <!-- > 10 < 100 -->
                          <?php if(($formHolder->order->id > 10) && ($formHolder->order->id < 100)): ?> 000<?php echo e($formHolder->order->id); ?> <?php endif; ?>
                          <!-- > 100 < 1000 -->
                          <?php if(($formHolder->order->id) > 100 && ($formHolder->order->id < 100)): ?> 00<?php echo e($formHolder->order->id); ?> <?php endif; ?>
                          <!-- > 1000 < 10000++ -->
                          <?php if(($formHolder->order->id) > 100 && ($formHolder->order->id < 100)): ?> 0<?php echo e($formHolder->order->id); ?> <?php endif; ?>
                          
                        </a>
                      </td>

                      <?php if(isset($formHolder->orderbump_id)): ?>
                      
                      <td>
                        <a
                        href="<?php echo e(asset('/storage/products/'.$formHolder->orderbump->product->image)); ?>"
                        data-fancybox="gallery"
                        data-caption="<?php echo e($formHolder->orderbump->product->name.', as OrderBump for '.$formHolder->name); ?>"
                        >   
                        <img src="<?php echo e(asset('/storage/products/'.$formHolder->orderbump->product->image)); ?>" width="30"
                        class="img-thumbnail img-fluid"
                        alt="<?php echo e($formHolder->orderbump->product->name); ?>" style="height: 30px;"></a>

                        <br>
                        <button class="btn btn-info btn-sm rounded" data-bs-target="#orderbumpEditModal<?php echo e($formHolder->id); ?>" data-bs-toggle="modal">
                          <i class="bi bi-pencil"></i> Edit</button>

                        <!-- Edit Ordernump-Modal Orderbump -->
                        <div class="modal fade orderbumpEditModal" id="orderbumpEditModal<?php echo e($formHolder->id); ?>" tabindex="-1" aria-hidden="true">
                          <div class="modal-dialog">
                            <div class="modal-content bg-white">
                              <div class="modal-header">
                                <h1 class="modal-title fs-5">Edit Order-Bump to this Form</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <form action="<?php echo e(route('editOrderbumpToForm', $formHolder->unique_key)); ?>" method="POST"><?php echo csrf_field(); ?>

                                <div class="modal-body">
                                  
                                  <div class="mt-3">
                                    <label for="" class="form-label">Heading</label>
                                    <input type="text" name="orderbump_heading"  class="form-control" value="<?php echo e($formHolder->orderbump->orderbump_heading); ?>">
                                  </div>

                                  <div class="mt-3">
                                    <label for="" class="form-label">Sub Heading</label>
                                    <input type="text" name="orderbump_subheading"  class="form-control" value="<?php echo e($formHolder->orderbump->orderbump_subheading); ?>">
                                  </div>

                                  <div class="mt-3">
                                    <label for="orderbump_product" class="form-label">Select Product Package</label>
                                    <select name="orderbump_product" data-live-search="true" class="custom-select form-control border btn-dark <?php $__errorArgs = ['orderbump_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                              id="" style="color: black !important;">
                                      <option value="<?php echo e($formHolder->orderbump->product->id); ?>" selected><?php echo e($formHolder->orderbump->product->name); ?></option>
                                      <?php if(count($products) > 0): ?>

                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                      <?php endif; ?>
                              
                                    </select>

                                    <?php $__errorArgs = ['orderbump_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="invalid-feedback mb-3" role="alert">
                                          <strong><?php echo e($message); ?></strong>
                                      </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>

                                  <div class="mt-3">
                                    <label for="" class="form-label">Discount Type</label>
                                    <select name="ordernump_discount_type" class="custom-select form-control border btn-dark">
                                      <option value="">Nothing Selected</option>
                                      <option value="fixed">Fixed</option>
                                      <option value="percentage">Percentage</option>
                                    </select>
                                  </div>

                                  <div class="mt-3">
                                    <label for="" class="form-label">Discount Amount</label>
                                    <input type="text" name="orderbump_discount" class="form-control" value="">
                                  </div>

                                </div>
                                
                                
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                  <button type="submit" class="btn btn-info"><i class="bi bi-send"></i> UPDATE</button>
                                </div>

                              </form>

                            </div>
                          </div>
                        </div>
                        <!--edit ordernump-modal-end--->
                      </td>

                      <?php else: ?>

                      <td><button class="btn btn-primary btn-sm rounded" data-bs-target="#orderbumpModal<?php echo e($formHolder->id); ?>" data-bs-toggle="modal">
                        <i class="bi bi-plus"></i> Add</button></td>

                      <!-- Modal Orderbump -->
                      <div class="modal fade orderbumpModal" id="orderbumpModal<?php echo e($formHolder->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content bg-white">
                            <div class="modal-header">
                              <h1 class="modal-title fs-5">Add Order-Bump to this Form</h1>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('addOrderbumpToForm', $formHolder->unique_key)); ?>" method="POST"><?php echo csrf_field(); ?>

                              <div class="modal-body">
                                
                                <div class="mt-3">
                                  <label for="" class="form-label">Heading</label>
                                  <input type="text" name="orderbump_heading"  class="form-control" value="">
                                </div>

                                <div class="mt-3">
                                  <label for="" class="form-label">Sub Heading</label>
                                  <input type="text" name="orderbump_subheading"  class="form-control" value="">
                                </div>

                                <div class="mt-3">
                                  <label for="orderbump_product" class="form-label">Select Product Package</label>
                                  <select name="orderbump_product" data-live-search="true" class="custom-select form-control border btn-dark <?php $__errorArgs = ['orderbump_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="" style="color: black !important;">
                                    <option value="">Nothing Selected</option>
                                    <?php if(count($products) > 0): ?>

                                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>
                            
                                  </select>

                                  <?php $__errorArgs = ['orderbump_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback mb-3" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mt-3">
                                  <label for="" class="form-label">Discount Type</label>
                                  <select name="ordernump_discount_type" class="custom-select form-control border btn-dark">
                                    <option value="">Nothing Selected</option>
                                    <option value="fixed">Fixed</option>
                                    <option value="percentage">Percentage</option>
                                  </select>
                                </div>

                                <div class="mt-3">
                                  <label for="" class="form-label">Discount Amount</label>
                                  <input type="text" name="orderbump_discount" class="form-control" value="">
                                </div>

                              </div>
                              
                              
                               <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> SUBMIT</button>
                              </div>

                            </form>

                          </div>
                        </div>
                      </div>
                      <!--modal-end--->
                      <?php endif; ?>
                      
                      <?php if(isset($formHolder->upsell_id)): ?>
                      
                      <td>
                        <a
                        href="<?php echo e(asset('/storage/products/'.$formHolder->upsell->product->image)); ?>"
                        data-fancybox="gallery"
                        data-caption="<?php echo e($formHolder->upsell->product->name.', as Upsell for '.$formHolder->name); ?>"
                        >   
                        <img src="<?php echo e(asset('/storage/products/'.$formHolder->upsell->product->image)); ?>" width="30"
                        class="img-thumbnail img-fluid"
                        alt="<?php echo e($formHolder->upsell->product->name); ?>" style="height: 30px;"></a>
                        <br>

                        <button class="btn btn-info btn-sm rounded" data-bs-target="#upsellEditModal<?php echo e($formHolder->id); ?>" data-bs-toggle="modal">
                          <i class="bi bi-pencil"></i> Edit</button>

                          <!-- Edit Upsell-Modal -->
                          <div class="modal fade upsellEditModal" id="upsellEditModal<?php echo e($formHolder->id); ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content bg-white">
                                <div class="modal-header">
                                  <h1 class="modal-title fs-5">Edit Upsell to this Form</h1>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('editUpsellToForm', $formHolder->unique_key)); ?>" method="POST"><?php echo csrf_field(); ?>

                                  <div class="modal-body">
                                    
                                    <div class="mt-3">
                                      <label for="" class="form-label">Heading</label>
                                      <input type="text" name="upsell_heading"  class="form-control" value="<?php echo e($formHolder->upsell->upsell_heading); ?>">
                                    </div>

                                    <div class="mt-3">
                                      <label for="" class="form-label">Sub Heading</label>
                                      <input type="text" name="upsell_subheading"  class="form-control" value="<?php echo e($formHolder->upsell->upsell_subheading); ?>">
                                    </div>

                                    <div class="mt-3">
                                      <label for="upsell_product" class="form-label">Select Product Package</label>
                                      <select name="upsell_product" data-live-search="true" class="custom-select form-control border btn-dark <?php $__errorArgs = ['upsell_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="" style="color: black !important;">
                                        <option value="<?php echo e($formHolder->upsell->product->id); ?>" selected><?php echo e($formHolder->upsell->product->name); ?></option>
                                        <?php if(count($products) > 0): ?>

                                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                
                                      </select>

                                      <?php $__errorArgs = ['upsell_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback mb-3" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="mt-3">
                                      <label for="" class="form-label">Discount Type</label>
                                      <select name="upsell_discount_type" class="custom-select form-control border btn-dark">
                                        <option value="">Nothing Selected</option>
                                        <option value="fixed">Fixed</option>
                                        <option value="percentage">Percentage</option>
                                      </select>
                                    </div>

                                    <div class="mt-3">
                                      <label for="" class="form-label">Discount Amount</label>
                                      <input type="text" name="upsell_discount" class="form-control" value="">
                                    </div>

                                  </div>
                                  
                                  
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-info"><i class="bi bi-send"></i> UPDATE</button>
                                  </div>

                                </form>

                              </div>
                            </div>
                          </div>
                          <!--edit Upsell-modal-end--->
                      </td>
                          
                      <?php else: ?>
                          
                      <td><button class="btn btn-primary btn-sm rounded" data-bs-target="#upsellModal<?php echo e($formHolder->id); ?>" data-bs-toggle="modal">
                        <i class="bi bi-plus"></i> Add</button></td>

                      <!-- Modal Upsell -->
                      <div class="modal fade <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> show <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="upsellModal<?php echo e($formHolder->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content bg-white">
                            <div class="modal-header">
                              <h1 class="modal-title fs-5">Add Upsell to this Form</h1>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('addUpsellToForm', $formHolder->unique_key)); ?>" method="POST"><?php echo csrf_field(); ?>
                              <div class="modal-body">

                                <div class="mt-3">
                                  <label for="" class="form-label">Heading</label>
                                  <input type="text" name="upsell_heading"  class="form-control" value="">
                                </div>

                                <div class="mt-3">
                                  <label for="" class="form-label">Sub Heading</label>
                                  <input type="text" name="upsell_subheading"  class="form-control" value="">
                                </div>
                                
                                <div class="mt-3">
                                  <label for="upsell_product" class="form-label">Select Product Package</label>
                                  <select name="upsell_product" data-live-search="true" class="custom-select form-control border btn-dark <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="" style="color: black !important;">
                                    <option value="">Nothing Selected</option>
                                    <?php if(count($products) > 0): ?>

                                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>
                            
                                  </select>

                                  <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback mb-3" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mt-3">
                                  <label for="" class="form-label">Discount Type</label>
                                  <select name="upsell_discount_type" class="custom-select form-control border btn-dark">
                                    <option value="">Nothing Selected</option>
                                    <option value="fixed">Fixed</option>
                                    <option value="percentage">Percentage</option>
                                  </select>
                                </div>

                                <div class="mt-3">
                                  <label for="" class="form-label">Discount Amount</label>
                                  <input type="text" name="upsell_discount" class="form-control" value="">
                                </div>

                              </div>
                              
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> SUBMIT</button>
                              </div>
                            </form>

                          </div>
                        </div>
                      </div>
                      <!--modal-end---->

                      <?php endif; ?>

                      <td><span><?php echo e($formHolder->order->customer_id ? $formHolder->order->customer->firstname : 'No response'); ?> <?php echo e($formHolder->order->customer_id ? $formHolder->order->customer->lastname : ''); ?></span></td>
                      <td>
                        
                        <div class="d-flex">
                          <a class="btn btn-info btn-sm me-2 clipboard-btn" data-bs-toggle="tooltip" data-bs-placement="top"
                            data-bs-title="Copy Url Link" data-clipboard-text="<?php echo e(url('/').'/'.$formHolder->url); ?>">
                            <i class="bi bi-clipboard"></i>
                          </a>

                          <a class="btn btn-secondary btn-sm me-2 clipboard-btn" data-bs-toggle="tooltip" data-bs-placement="top"
                            data-bs-title="Copy Embedded Code" data-clipboard-text="<?php echo e($formHolder->iframe_tag); ?>">
                            <i class="bi bi-archive"></i>
                          </a>

                          <a href="<?php echo e(route('newFormLink', $formHolder->unique_key)); ?>" class="btn btn-primary btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="View"><i class="bi bi-eye"></i></a>
                          <a href="<?php echo e(route('editForm', $formHolder->unique_key)); ?>" class="btn btn-success btn-sm me-2 d-none" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit"><i class="bi bi-pencil-square"></i></a>
                          <a class="btn btn-danger btn-sm" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Delete"><i class="bi bi-trash"></i></a>
                        </div>
                      </td>
                    </tr>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                <?php endif; ?>

                
              </tbody>
            </table>
          </div>
          </div>
        </div>
      </div>
    </div>
  </section>

</main><!-- End #main -->



<!-- Modal Upsell -->
<div class="modal fade" id="upsellModal" tabindex="-1" aria-labelledby="upsellModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="upsellModalLabel">Add Upsell to this Form</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="">
      <div class="modal-body">
        
        <div class="mt-3">
          <label for="product" class="form-label">Select Product Package</label>
          <select name="agent_assigned" data-live-search="true" class="custom-select form-control border btn-dark <?php $__errorArgs = ['agent_assigned'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="" style="color: black !important;">
            <option value="">Nothing Selected</option>
            <?php if(count($products) > 0): ?>

              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
    
          </select>
        </div>
      </div>
      </form>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary"><i class="bi bi-send"></i> SUBMIT</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>
<script>
  new ClipboardJS('.clipboard-btn');
</script>


    

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/allFormBuilders.blade.php ENDPATH**/ ?>
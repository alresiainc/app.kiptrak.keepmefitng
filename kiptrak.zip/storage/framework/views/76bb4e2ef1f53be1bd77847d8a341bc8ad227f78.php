
<?php $__env->startSection('title'); ?>View Staff <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Staff Information</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Staff Information<li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <hr>
    <section>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            
            <div class="card-body pt-3">
              <div class="card-title clearfix">
                <div class="d-lg-flex d-grid align-items-center float-start">
                  <div>
                    <?php if(isset($staff->profile_picture)): ?>
                        <a
                        href="<?php echo e(asset('/storage/staff/'.$staff->profile_picture)); ?>"
                        data-caption="<?php echo e(isset($staff->name) ? $staff->name : 'no caption'); ?>"
                        data-fancybox
                        > 
                        <img src="<?php echo e(asset('/storage/staff/'.$staff->profile_picture)); ?>" width="100" class="img-thumbnail img-fluid"
                        alt="Photo"></a>
                    <?php else: ?>
                    <img src="<?php echo e(asset('/storage/staff/person.png')); ?>" width="100" class="img-thumbnail img-fluid"
                    alt="Photo"> 
                    <?php endif; ?>
                    
                  </div>
                  <div class="d-grid ms-lg-3">
                    <div class="display-6"><?php echo e($staff->name); ?></div>
                    <h5><?php echo e($staff->state); ?> | <?php echo e($staff->country->name); ?></h5>

                    <?php if($staff->status == 'true'): ?>
                      <div class="d-flex justify-content-start">
                        <small class="text-success me-2">Active</small>
                      </div>
                    <?php else: ?>
                      <small class="text-danger">Inactive</small>
                    <?php endif; ?>
                    
                  </div>
                </div>
                <div class="float-lg-end">
                  <button class="btn btn-sm btn-success"><i class="bi bi-pencil-square"></i></button>
                </div>
              </div>

              <hr>

              <div class="row g-3">
                <div class="col-lg-3">
                  <label for="">Phone Numbers</label>
                  <div class="lead"><?php echo e($staff->phone_1); ?>

                    <?php if(isset($staff->phone_2)): ?>
                        <br> <?php echo e($staff->phone_2); ?>

                    <?php endif; ?>
                </div>
                </div>

                
                <div class="col-lg-3">
                  <label for="">City/Town</label>
                  <div class="lead"><?php if(isset($staff->city)): ?><?php echo e($staff->city); ?> <?php else: ?> N/A <?php endif; ?></div>
                </div>
               
                <div class="col-lg-3">
                  <label for="">Address</label>
                  <div class="lead"><?php if(isset($staff->address)): ?><?php echo e($staff->address); ?> <?php else: ?> N/A <?php endif; ?></div>
                </div>
                
                <div class="col-lg-3">
                  <label for="">Date Joined</label>
                  <div class="lead"><?php echo e($staff->created_at); ?></div>
                </div>
                
              </div>

              <!--features-->
              

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/staff/singleStaff.blade.php ENDPATH**/ ?>
<footer id="footer" class="footer">
    <div class="copyright">
      &copy; <span class="copyright-date"></span> <strong><span class="project-name"></span></strong>. All rights reserved
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
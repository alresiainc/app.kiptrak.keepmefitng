
<?php $__env->startSection('title'); ?>View Order <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Cart Abandoned Information</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Cart Abandoned Information<li>
        </ol>
      </nav>
    </div><!-- End Page Title -->
    <hr>
    <section>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            
            <div class="row g-3 m-1">
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Cart Abandoned ID</label>
                    <div class="text-dark display-6">kpcart-0<?php echo e($cart->id); ?></div>
                </div>
                
                <div class="col-lg-5">
                    <label for="" class="fw-bolder">Customer</label>
                    <?php $__currentLoopData = $customer_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php if(str_contains($info, 'first-name')): ?>
                        <div>First Name: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></div>
                        <?php endif; ?>

                        <?php if(str_contains($info, 'last-name')): ?>
                        <div>Last Name: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>

                        <?php if(substr($info, strpos($info, '|') + 1) == 'active-email'): ?>
                        <div>Email: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>

                        <?php if(substr($info, strpos($info, '|') + 1) == 'phone-number'): ?>
                        <div>Phone: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>

                        <?php if(substr($info, strpos($info, '|') + 1) == 'whatsapp-phone-number'): ?>
                        <div>Whatsapp Phone: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>

                        <?php if(substr($info, strpos($info, '|') + 1) == 'city'): ?>
                        <div>City: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>

                        <?php if(substr($info, strpos($info, '|') + 1) == 'state'): ?>
                        <div>State: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>

                        <?php if(substr($info, strpos($info, '|') + 1) == 'delivery-address'): ?>
                        <div>Address: <span class="lead"><?php echo e(substr($info, 0, strpos($info, '|'))); ?></span></div>
                        <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-lg-2">
                    <label for="" class="fw-bolder">Expected Revenue</label>
                    <div class="text-dark display-6"><?php echo e($currency); ?><?php echo e($gross_revenue); ?></div>
                </div>
                <div class="col-lg-2">
                    <label for="" class="fw-bolder">Agent</label>
                    <div class="text-dark"></div>
                </div>
                    
                    
                    
            </div>
                
            </div>

            <div class="row g-3 m-1">
                <div class="col-lg-3">

                </div>
            </div>

            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <hr>
            <div class="row g-3 m-1">
            
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Product Name</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($package['product']->name); ?></div>
                    <?php if(in_array($package['product']->id, $package_info )): ?>
                        <span class="badge badge-danger">selected</span>
                    <?php endif; ?>
                </div>

                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Quantity</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($package['quantity_removed'].' @'. $package['product']->price); ?></div>
                </div>
                
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Revenue</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($package['revenue']); ?></div>
                </div>
                
                <div class="col-lg-3">
                    <label for="" class="fw-bolder">Date</label>
                    <div class="text-dark" style="font-size: 14px;"><?php echo e($order->created_at); ?></div>
                </div>
            
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

              <!--features-->
              

            </div>
          </div>
        </div>
      </div>
    </section>

</main><!-- End #main -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crm\crm-app\resources\views/pages/orders/singleCartAbandon.blade.php ENDPATH**/ ?>
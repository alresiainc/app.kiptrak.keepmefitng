<?php
function kiptrak_update_check()
{
    // Get the site URL and remove any trailing slashes
    $kiptrakSiteUrl = rtrim(get_option('kiptrak_backend_url'), '/');
    $plugin_url = $kiptrakSiteUrl . '/wordpress-plugin/';

    // Check if the site URL is set
    if (empty($kiptrakSiteUrl)) {
        error_log('Kiptrak Plugin: The Kiptrak Site URL is not set. Please configure it in the plugin settings.');
        return; // Exit early if no URL is set
    }

    // Construct the update check URL
    $updateCheckUrl = $kiptrakSiteUrl . '/wordpress-plugin/check-update';

    // Log the update check URL
    error_log('Kiptrak Plugin: Initializing the updater with URL ' . $updateCheckUrl);

    // Get the correct plugin basename from the main plugin file
    $plugin_basename = KIPTRAK_PLUGIN_BASENAME; // Adjust to point to index.php

    // Check for updates
    add_filter('pre_set_site_transient_update_plugins', function ($transient) use ($updateCheckUrl, $plugin_url, $plugin_basename) {
        error_log('KiptrakUpdater Class: Constructor called successfully.');

        // Make the API request
        $response = wp_remote_get($updateCheckUrl);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            error_log('Kiptrak Plugin: Update check failed - ' . wp_remote_retrieve_response_message($response));
            return $transient;
        }

        $data = json_decode(wp_remote_retrieve_body($response));
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Kiptrak Plugin: JSON decode error - ' . json_last_error_msg());
            return $transient;
        }

        if (isset($data->new_version) && isset($data->download_url)) {
            if (version_compare($data->new_version, get_plugin_data(KIPTRAK_PLUGIN_BASENAME)['Version'], '>')) {
                error_log('Kiptrak Plugin: Update available - Version ' . $data->new_version);
                $plugin_info = new stdClass();
                $plugin_info->slug = $plugin_basename;
                $plugin_info->new_version = $data->new_version;
                $plugin_info->url = $plugin_url; // Assuming the homepage is in the API response
                $plugin_info->package = $data->download_url;

                error_log(json_encode($plugin_info));
                $transient->response[$plugin_basename] = $plugin_info;
            }
        } else {
            error_log('Kiptrak Plugin: Update data is missing. Response: ' . json_encode($data));
        }

        return $transient;
    });

    // Add a filter for plugin information
    // add_filter('plugins_api', function ($false, $action, $response) use ($updateCheckUrl, $plugin_url, $plugin_basename) {
    //     error_log('Kiptrak Plugin: Update available');
    //     error_log(json_encode($response));
    //     if (isset($response->slug) && $response->slug === $plugin_basename) {
    //         // Make the API request again to fetch additional info
    //         $response = wp_remote_get($updateCheckUrl);
    //         if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
    //             return $false;
    //         }
    //         $data = json_decode(wp_remote_retrieve_body($response));
    //         if (json_last_error() !== JSON_ERROR_NONE) {
    //             error_log('Kiptrak Plugin: JSON decode error - ' . json_last_error_msg());
    //         }

    //         error_log(json_encode($response));
    //         if (isset($data->new_version)) {
    //             error_log('Kiptrak Plugin: Update available - Version ' . $data->new_version);
    //             // Prepare the response
    //             $response->new_version = $data->new_version; // Use the version from the API
    //             $response->slug = $plugin_basename;
    //             $response->plugin = $plugin_basename;
    //             $response->tested = '6.3';
    //             $response->requires = '5.6';
    //             $response->author = '<a href="https://alresia.com">Alresia</a>';
    //             $response->homepage = $plugin_url; // URL for the plugin homepage
    //             $response->download_link = $data->download_url; // Download link from the API
    //             $response->sections = array(
    //                 'description' => 'Kiptrak plugin connects your WordPress site with the Kiptrak backend app.',
    //                 'changelog' => 'Version ' . $data->new_version . ': Fixed bugs and improved performance.',
    //             );

    //             return $response;
    //         }
    //     }

    //     return $false;
    // }, 20, 3);

    add_filter('plugins_api', function ($false, $action, $response) use ($updateCheckUrl, $plugin_url, $plugin_basename) {
        error_log('Kiptrak Plugin: Update available');


        // Check if the response is an object and if the slug matches
        if (is_object($response) && isset($response->slug) && $response->slug === $plugin_basename) {
            // Make the API request again to fetch additional info
            $response_remote = wp_remote_get($updateCheckUrl);

            if (is_wp_error($response_remote) || wp_remote_retrieve_response_code($response_remote) !== 200) {
                return $false;
            }

            $data = json_decode(wp_remote_retrieve_body($response_remote));

            if (json_last_error() !== JSON_ERROR_NONE) {
                error_log('Kiptrak Plugin: JSON decode error - ' . json_last_error_msg());
                return $false;
            }



            if (isset($data->new_version)) {
                error_log('Kiptrak Plugin: Update available - Version ' . $data->new_version);

                // $plugin_data = get_plugin_data(KIPTRAK_PLUGIN_BASENAME);
                // Get plugin data from the main plugin file
                $plugin_data = get_plugin_data(plugin_dir_path(__FILE__) . '../kiptrak-backend.php'); 
                error_log('error_log');
                error_log(json_encode($plugin_data));

                // Prepare a new stdClass object for the response
                $new_response = new stdClass();
                $new_response->new_version = $data->new_version; // Use the version from the API
                $new_response->name = $plugin_data['Name'];
                $new_response->slug = $plugin_basename;
                $new_response->plugin = $plugin_basename;
                $new_response->tested = $data->tested;
                $new_response->requires = $data->requires;
                $new_response->author = '<a href="https://github.com/alresiainc">Alresia</a>';
                $new_response->homepage = $plugin_url; // URL for the plugin homepage
                $new_response->download_link = $data->download_url; // Download link from the API
                $new_response->sections = array(
                    'description' => $plugin_data['Description'],
                    'changelog' => $data->changelog,
                );
                error_log(json_encode($new_response));

                return $new_response; // Return the new response object
            }
        }

        return $false; // Return false if not applicable
    }, 20, 3);
}